#!/bin/sh
python3 tools/gclient_hook.py
